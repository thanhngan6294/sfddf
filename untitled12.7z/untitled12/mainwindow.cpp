#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QApplication>
#include <QMainWindow>
#include <QMouseEvent>
#include <QMessageBox>
#include <QTabWidget>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include "qdialog.h"
#include "qfileinfo.h"
#include <QFileInfo>
#include "tabdialog.h"
MainWindow::MainWindow (QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //setCentralWidget(tabs);
}

MainWindow::~MainWindow()
{
    delete ui;
}
#ifndef QT_NO_DOUBLECLICK
void MainWindow::mouseDoubleClickEvent ( QMouseEvent * event )
    {
    //TabDialog mdialog;
   // mDialog = new TabDialog(this);
//    mdialog.setModal(true);
//    mdialog.exec();
   //mDialog->show();
//    TabDialog mDialog;
//    mDialog.setModal(false);
//    mDialog.exec();
//    mDialog.show();
   }
#endif
