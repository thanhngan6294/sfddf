#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QApplication>
#include <QMouseEvent>
#include <QMessageBox>
#include <QTabWidget>
#include <QWidget>
#include <QDialogButtonBox>
#include "tabdialog.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);

    ~MainWindow();
//    QTabBar* tabBar()
//        {
//          return QTabWidget::tabBar();
//        }
private:
    Ui::MainWindow *ui;
    //QMessageBox* msgBox;
    QTabWidget *tabWidget;
    QWidget *centralWidget;
    QAction *name;
    QDialogButtonBox *buttonBox;
    TabDialog *mDialog;
    //QString &fileName;
//private slots:
//    void mouseDoubleClickEvent ( QMouseEvent * event );
//public slots:
//  void myItemChangeSlot(int index)
//  {
//    this->tabBar()->setTabIcon(index,*(new QIcon("up_arrow.gif")));

//    for(int i = 0;i<this->tabBar()->count();i++)
//    {
//        if(i != index)
//          this->tabBar()->setTabIcon(i,*(new QIcon()));
//    }
//  }
protected:
#ifndef QT_NO_DOUBLECLICK
    void mouseDoubleClickEvent(QMouseEvent * event) override;
#endif // QT_NO_CONTEXTMENU

};

#endif // MAINWINDOW_H
