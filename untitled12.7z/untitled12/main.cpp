#include "mainwindow.h"
#include <QApplication>
#include <QApplication>
#include <QMainWindow>
#include <QMouseEvent>
#include <QMessageBox>
#include "tabdialog.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    w.setWindowTitle(QString::fromUtf8("QT - Capture Mouse Double Click"));
    w.resize(300, 250);
    return a.exec();
}
